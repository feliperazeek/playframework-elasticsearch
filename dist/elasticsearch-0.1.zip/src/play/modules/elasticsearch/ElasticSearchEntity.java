package play.modules.elasticsearch;

import javax.persistence.MappedSuperclass;
import javax.persistence.PostPersist;

import play.Logger;
import play.Play;
import play.db.jpa.Model;

// TODO: Auto-generated Javadoc
/**
 * The Interface ElasticSearchEntity.
 */
@MappedSuperclass
public class ElasticSearchEntity<T extends ElasticSearchEntity> extends Model {
	
	/**
	 * Post.
	 */
	@PostPersist
	public void post() {
		try {
			Logger.info("Elastic Event Start - Object: " + this + ", Key: " + this.id + "/" + this._key());
			ElasticSearchPlugin plugin = Play.plugin(ElasticSearchPlugin.class);	
			ElasticSearchAdapter<T> adapter = new ElasticSearchAdapter<T>();
			adapter.indexModel(plugin.client(), this.getClass().getName(), (T)this);
			Logger.info("Elastic Event Done!");

		} catch (Throwable t) {
			throw new RuntimeException(t);
		}

	}

}
