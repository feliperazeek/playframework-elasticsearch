package play.modules.elasticsearch;

import static org.elasticsearch.node.NodeBuilder.nodeBuilder;

import org.elasticsearch.client.Client;
import org.elasticsearch.node.Node;
import org.elasticsearch.node.NodeBuilder;

import play.Logger;
import play.Play;
import play.PlayPlugin;
import play.db.Model;

// TODO: Auto-generated Javadoc
/**
 * The Class ElasticSearchPlugin.
 */
public class ElasticSearchPlugin extends PlayPlugin {

	/** The _session. */
	private ThreadLocal<Client> _session = new ThreadLocal<Client>();

	public static boolean started = false;

	/**
	 * Client.
	 * 
	 * @return the client
	 */
	public Client client() {
		return _session.get();
	}

	/**
	 * Elastic Search Start
	 * 
	 * @see play.PlayPlugin#onApplicationStart()
	 */
	@Override
	public void onApplicationStart() {
		if (_session.get() != null || started) {
			Logger.warn("Started Already!");
			return;
		}

		NodeBuilder nb = nodeBuilder();

		boolean localMode = false;
		if (!Play.configuration.containsKey("elasticsearch.local")) {
			localMode = Boolean.getBoolean(Play.configuration
					.getProperty("elasticsearch.local"));
			nb = nb.local(localMode);
		}

		boolean clientMode = false;
		if (!Play.configuration.containsKey("elasticsearch.client")) {
			clientMode = Boolean.getBoolean(Play.configuration
					.getProperty("elasticsearch.client"));
			nb = nb.client(clientMode);
		}

		if (localMode == false && clientMode == false) {
			localMode = true;
			nb = nb.local(localMode);
		}

		if (localMode) {
			Logger.info("Starting Play! Elastic Search in Local Mode");
		} else {
			Logger.info("Starting Play! Elastic Search in Client Mode");
		}

		started = true;

		Node node = nb.node();
		Client client = node.client();

		_session.set(client);

	}

}