package play.modules.elasticsearch;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.elasticsearch.action.delete.DeleteResponse;
import org.elasticsearch.action.get.GetResponse;
import org.elasticsearch.client.Client;
import org.elasticsearch.common.xcontent.XContentBuilder;
import org.elasticsearch.common.xcontent.XContentFactory;

import play.Logger;
import play.db.Model;

// TODO: Auto-generated Javadoc
/**
 * The Class ElasticSearchAdapter.
 */
public class ElasticSearchAdapter<T extends ElasticSearchEntity> {

	/**
	 * Index model.
	 *
	 * @param client the client
	 * @param indexName the index name
	 * @param model the model
	 * @throws Exception the exception
	 */
	public void indexModel(Client client, String indexName,  T model) throws Exception {
		Logger.info("Index Model: %s", model);

		XContentBuilder b = XContentFactory.jsonBuilder().startObject();
		List<String> fields = ReflectionUtil.getAllFieldNamesWithoutAnnotation(model.getClass(), ElasticSearchIgnore.class);
		for ( String name : fields ) {
			if ( StringUtils.isNotBlank(name) ) {
				Object value = ReflectionUtil.getFieldValue(model, name);
				if ( value != null ) {
					Logger.info("Field: " + name + ", Value: " + value);
					b.field(name, value);
				} else {
					Logger.info("No Value for Field: " + name);
				}
			}
		}
		

		b.endObject();

		GetResponse response = client.prepareGet(indexName, indexName, String.valueOf(model._key())).execute().actionGet();
		Logger.info("Index Response: %s", response);
	}

	/**
	 * Delete model.
	 *
	 * @param client the client
	 * @param indexName the index name
	 * @param model the model
	 * @throws Exception the exception
	 */
	public void deleteModel(Client client, String indexName, Model model)
			throws Exception {
		Logger.info("Delete Model: %s", model);

		DeleteResponse response = client.prepareDelete(indexName.toLowerCase(), indexName.toLowerCase(),
				String.valueOf(model._key())).setOperationThreaded(false)
				.execute().actionGet();
		
		Logger.info("Delete Response: %s", response);

	}

}
